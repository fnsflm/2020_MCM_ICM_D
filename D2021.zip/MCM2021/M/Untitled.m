clc
clear all
close all
A1 = xlsread('C:\Users\Cauchy\Desktop\MCM2021\PASSTYPE.xlsx','HEAD');
A2 = xlsread('C:\Users\Cauchy\Desktop\MCM2021\PASSTYPE.xlsx','HIGH');
A3 = xlsread('C:\Users\Cauchy\Desktop\MCM2021\PASSTYPE.xlsx','SIMPLE');
a1=sqrt((A1(:,8)-A1(:,10)).^2+(A1(:,9)-A1(:,11)).^2);
a2=sqrt((A2(:,8)-A2(:,10)).^2+(A2(:,9)-A2(:,11)).^2);
a3=sqrt((A3(:,8)-A3(:,10)).^2+(A3(:,9)-A3(:,11)).^2);
a1=sort(a1);
a2=sort(a2);
a3=sort(a3);
histogram(a1);
hold on;
histogram(a2);
hold on;
histogram(a3);