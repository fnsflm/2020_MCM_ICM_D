clc
clear all
close all
A1 = xlsread('C:\Users\Cauchy\Desktop\MCM2021\PASSTYPE2.xlsx','HEAD');
A2 = xlsread('C:\Users\Cauchy\Desktop\MCM2021\PASSTYPE2.xlsx','HIGH');
A3 = xlsread('C:\Users\Cauchy\Desktop\MCM2021\PASSTYPE2.xlsx','SIMPLE');
a1=A1(:,4);
a2=A2(:,4);
a3=A3(:,4);
for j=1:2298
    if a1(j)~=0
        a1(j)=1;
    end
end
for j=1:2585
    if a2(j)~=0
        a2(j)=2;
    end
end
for j=1:2298
    if a1(j)~=0
        a1(j)=1;
    end
end